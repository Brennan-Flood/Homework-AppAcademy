class User < ApplicationRecord
  validates :username, :session_token, presence: true
  validates :password_digest, presence: true, message: 'Password can''t be blank'
  validates :password, allow_nil: true

  def find_by_credentials(username, password)
    
  end

  def generate_session_token

  end
end
